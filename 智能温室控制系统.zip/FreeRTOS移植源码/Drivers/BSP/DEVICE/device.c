#include "./BSP/DEVICE/device.h"

/* ���� - PA6 �͵�ƽ��Ч */
#define FAN_GPIO_PORT       GPIOA
#define FAN_GPIO_PIN        GPIO_PIN_6
#define FAN_GPIO_CLK_EN()   __HAL_RCC_GPIOA_CLK_ENABLE()

/* ˮ�� - PE1 �ߵ�ƽ��Ч */
#define PUMP_GPIO_PORT      GPIOE
#define PUMP_GPIO_PIN       GPIO_PIN_1
#define PUMP_GPIO_CLK_EN()  __HAL_RCC_GPIOE_CLK_ENABLE()

/* ����� - PE0 �ߵ�ƽ��Ч */
#define LIGHT_GPIO_PORT     GPIOE
#define LIGHT_GPIO_PIN      GPIO_PIN_0
#define LIGHT_GPIO_CLK_EN() __HAL_RCC_GPIOE_CLK_ENABLE()

/* ������ - PB8 �ߵ�ƽ��Ч */
#define BUZZER_GPIO_PORT    GPIOB
#define BUZZER_GPIO_PIN     GPIO_PIN_8
#define BUZZER_GPIO_CLK_EN() __HAL_RCC_GPIOB_CLK_ENABLE()

/* �豸��ǰ״̬���� */
static DeviceState_t g_device_states[DEVICE_COUNT] = {DEVICE_OFF};

/* ��ʼ�� GPIO */
void devices_init(void)
{
    GPIO_InitTypeDef gpio_init = {0};

    /* ��ʼ������ PA6���ϵ�Ĭ�ϸߵ�ƽ���رգ�*/
    FAN_GPIO_CLK_EN();
    gpio_init.Pin = FAN_GPIO_PIN;
    gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull = GPIO_PULLDOWN;
    gpio_init.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(FAN_GPIO_PORT, &gpio_init);
    HAL_GPIO_WritePin(FAN_GPIO_PORT, FAN_GPIO_PIN, GPIO_PIN_SET);

    /* ��ʼ��ˮ�� PE1���ϵ�Ĭ�ϵ͵�ƽ���رգ�*/
    PUMP_GPIO_CLK_EN();
    gpio_init.Pin = PUMP_GPIO_PIN;
    HAL_GPIO_Init(PUMP_GPIO_PORT, &gpio_init);
    HAL_GPIO_WritePin(PUMP_GPIO_PORT, PUMP_GPIO_PIN, GPIO_PIN_RESET);

    /* ��ʼ������� PE0���ϵ�Ĭ�ϵ͵�ƽ���رգ�*/
    LIGHT_GPIO_CLK_EN();
    gpio_init.Pin = LIGHT_GPIO_PIN;
    HAL_GPIO_Init(LIGHT_GPIO_PORT, &gpio_init);
    HAL_GPIO_WritePin(LIGHT_GPIO_PORT, LIGHT_GPIO_PIN, GPIO_PIN_RESET);

    /* ��ʼ�������� PB8���ϵ�Ĭ�ϵ͵�ƽ���رգ�*/
    BUZZER_GPIO_CLK_EN();
    gpio_init.Pin = BUZZER_GPIO_PIN;
    HAL_GPIO_Init(BUZZER_GPIO_PORT, &gpio_init);
    HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_GPIO_PIN, GPIO_PIN_RESET);
}

/* �����豸 */
void device_control(Device_t device, DeviceState_t state)
{
    if (device >= DEVICE_COUNT) return;
    g_device_states[device] = state;

    switch (device) {
        case DEVICE_FAN:
            HAL_GPIO_WritePin(FAN_GPIO_PORT, FAN_GPIO_PIN,
                              (state == DEVICE_ON) ? GPIO_PIN_RESET : GPIO_PIN_SET);
            break;
        case DEVICE_PUMP:
            HAL_GPIO_WritePin(PUMP_GPIO_PORT, PUMP_GPIO_PIN,
                              (state == DEVICE_ON) ? GPIO_PIN_SET : GPIO_PIN_RESET);
            break;
        case DEVICE_LIGHT:
            HAL_GPIO_WritePin(LIGHT_GPIO_PORT, LIGHT_GPIO_PIN,
                              (state == DEVICE_ON) ? GPIO_PIN_SET : GPIO_PIN_RESET);
            break;
        case DEVICE_BUZZER:
            HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_GPIO_PIN,
                              (state == DEVICE_ON) ? GPIO_PIN_SET : GPIO_PIN_RESET);
            break;
        default:
            break;
    }
}

/* ��ȡ�豸״̬ */
DeviceState_t device_get_state(Device_t device)
{
    if (device >= DEVICE_COUNT) return DEVICE_OFF;
    return g_device_states[device];
}
