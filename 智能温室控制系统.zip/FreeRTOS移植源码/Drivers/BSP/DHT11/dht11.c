#include "./BSP/DHT11/dht11.h"

// 私有函数声明
static void DHT11_GPIO_Output(void);
static void DHT11_GPIO_Input(void);
static void DHT11_StartSignal(void);
static uint8_t DHT11_ReadByte(void);
static uint8_t DHT11_WaitForLevel(GPIO_PinState level, uint32_t timeout);

/**
 * @brief DHT11初始化函数
 */
void DHT11_Init(void) {
    // PA5已由HAL_GPIO_Init初始化
    // 设置初始状态为输出高电平
    DHT11_GPIO_Output();
    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
}

/**
 * @brief 将DHT11引脚设置为输出模式
 */
static void DHT11_GPIO_Output(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}

/**
 * @brief 将DHT11引脚设置为输入模式
 */
static void DHT11_GPIO_Input(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}


/**
 * @brief 发送开始信号
 */
static void DHT11_StartSignal(void) {
    // 设置引脚为输出模式
    DHT11_GPIO_Output();
    
    // 拉低至少18ms
    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_RESET);
    delay_ms(20);  // 延时20ms确保满足要求
    
    // 拉高20-40us
    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
    delay_us(30);  // 延时30us
}

/**
 * @brief 等待引脚达到指定电平
 * @param level 等待的电平
 * @param timeout 超时时间（微秒）
 * @return 0:超时, 1:成功
 */
static uint8_t DHT11_WaitForLevel(GPIO_PinState level, uint32_t timeout) {
    uint32_t time = 0;
    
    while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) != level) {
        delay_us(1);
        time++;
        if (time > timeout) {
            return 0;  // 超时
        }
    }
    return 1;  // 成功
}

/**
 * @brief 读取一个字节的数据
 * @return 读取到的字节
 */
static uint8_t DHT11_ReadByte(void) {
    uint8_t byte = 0;
    uint8_t bit;
    
    for (bit = 0; bit < 8; bit++) {
        // 等待低电平结束（每个位都以50us低电平开始）
        if (!DHT11_WaitForLevel(GPIO_PIN_SET, 100)) {
            return 0;  // 超时
        }
        
        // 延时30us后检测电平
        delay_us(30);
        
        // 如果此时为高电平，则数据为1，否则为0
        if (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET) {
            byte |= (1 << (7 - bit));  // 高位在前
            // 等待高电平结束
            if (!DHT11_WaitForLevel(GPIO_PIN_RESET, 100)) {
                return 0;  // 超时
            }
        }
    }
    
    return byte;
}

/**
 * @brief 读取DHT11传感器数据
 * @param data 存储读取到的数据
 * @return 状态码: DHT11_OK=成功, DHT11_ERROR=校验失败, DHT11_TIMEOUT=超时
 */
uint8_t DHT11_Read(DHT11_Data *data) {
    if (data == NULL) {
        return DHT11_ERROR;
    }
    
    // 发送开始信号
    DHT11_StartSignal();
    
    // 设置为输入模式
    DHT11_GPIO_Input();
    
    // 等待DHT11响应（低电平80us）
    if (!DHT11_WaitForLevel(GPIO_PIN_RESET, 100)) {
        return DHT11_TIMEOUT;
    }
    
    // 等待DHT11拉高80us
    if (!DHT11_WaitForLevel(GPIO_PIN_SET, 100)) {
        return DHT11_TIMEOUT;
    }
    
    // 等待DHT11拉低80us（数据开始）
    if (!DHT11_WaitForLevel(GPIO_PIN_RESET, 100)) {
        return DHT11_TIMEOUT;
    }
    
    // 开始读取40位数据
    data->humidity = DHT11_ReadByte();     // 湿度整数部分
    data->humi_decimal = DHT11_ReadByte(); // 湿度小数部分
    data->temperature = DHT11_ReadByte();  // 温度整数部分
    data->temp_decimal = DHT11_ReadByte(); // 温度小数部分
    data->checksum = DHT11_ReadByte();     // 校验和
    
    // 计算校验和（前4个字节的和）
    uint8_t sum = data->humidity + data->humi_decimal + 
                  data->temperature + data->temp_decimal;
    
    // 验证校验和
    if (data->checksum != sum) {
        return DHT11_ERROR;  // 校验失败
    }
    
    // 设置为输出模式（释放总线）
    DHT11_GPIO_Output();
    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
    
    return DHT11_OK;  // 读取成功
}
