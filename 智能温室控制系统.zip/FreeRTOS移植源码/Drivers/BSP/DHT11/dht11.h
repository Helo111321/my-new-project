#ifndef __DHT11_H
#define __DHT11_H

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/delay/delay.h"

// DHT11引脚定义
#define DHT11_PIN          GPIO_PIN_5
#define DHT11_PORT         GPIOA

// DHT11数据类型定义
typedef struct {
    uint8_t temperature;   // 温度（整数部分）
    uint8_t humidity;      // 湿度（整数部分）
    uint8_t temp_decimal;  // 温度小数部分
    uint8_t humi_decimal;  // 湿度小数部分
    uint8_t checksum;      // 校验和
} DHT11_Data;

// 函数声明
void DHT11_Init(void);
uint8_t DHT11_Read(DHT11_Data *data);
void DHT11_Delay_us(uint16_t us);
void DHT11_Delay_ms(uint16_t ms);

// 错误码定义
#define DHT11_OK           0
#define DHT11_ERROR        1
#define DHT11_TIMEOUT      2

#endif /* __DHT11_H */
