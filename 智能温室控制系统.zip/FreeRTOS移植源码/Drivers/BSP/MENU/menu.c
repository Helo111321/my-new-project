#include "./BSP/MENU/menu.h"

/* ==================== ��ֵ�洢���� ==================== */
#define THRESHOLD_START_ADDR    0x000000
#define THRESHOLD_DATA_SIZE     (THRESH_COUNT * sizeof(int16_t))

/* ==================== ���������ݽṹ ==================== */
typedef enum {
    MENU_THRESHOLD = 0,
    MENU_MANUAL,
    MENU_COUNT
} menu_item_t;

static menu_item_t g_selected_item = MENU_THRESHOLD;
static menu_item_t g_last_selected_item = MENU_THRESHOLD;

/* ��ʾ������� */
#define SENSOR_START_Y      5
#define SENSOR_LINE_H       24
#define MENU_START_Y        (SENSOR_START_Y + SENSOR_LINE_H * 4)
#define MENU_ITEM_H         32
#define ARROW_X             20
#define TEXT_X              50
#define BG_COLOR            BLACK
#define LABEL_COLOR         WHITE
#define VALUE_COLOR         YELLOW
#define MENU_NORMAL_COLOR   WHITE
#define MENU_SELECTED_COLOR RED

/* ==================== ��ֵ�������� ==================== */
typedef enum {
    THRESH_TEMP = 0,
    THRESH_HUM,
    THRESH_LIGHT,
    THRESH_SOIL,
    THRESH_COUNT
} thresh_item_t;

/* ��ֵ���飨ȫ�֣����Զ���������ʹ�ã�*/
int16_t g_thresholds[THRESH_COUNT] = {30, 80, 70, 60};

static void load_thresholds(void)
{
    uint8_t buf[THRESHOLD_DATA_SIZE];
    w25q64_read_bytes(THRESHOLD_START_ADDR, buf, THRESHOLD_DATA_SIZE);
    if ((buf[0] == 0xFF && buf[1] == 0xFF && buf[2] == 0xFF && buf[3] == 0xFF) ||
        (buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 && buf[3] == 0x00)) {
        return;
    }
    memcpy(g_thresholds, buf, THRESHOLD_DATA_SIZE);
}

static void save_thresholds(void)
{
    w25q64_erase_sector(THRESHOLD_START_ADDR);
    w25q64_write_bytes(THRESHOLD_START_ADDR, (uint8_t*)g_thresholds, THRESHOLD_DATA_SIZE);
}

/* ==================== ��������ʾ���� ==================== */
static void display_sensor_line_float(uint16_t y, const char *label, float value, const char *unit)
{
    char val_buf[16], disp_buf[32];
    lcd_show_string(10, y, 200, 24, 16, (char *)label, LABEL_COLOR);
    sprintf(val_buf, "%5.1f", value);
    sprintf(disp_buf, "%s %s", val_buf, unit);
    lcd_show_string(150, y, 200, 24, 16, disp_buf, VALUE_COLOR);
}

static void display_sensor_line_int(uint16_t y, const char *label, uint16_t value, const char *unit)
{
    char val_buf[16], disp_buf[32];
    lcd_show_string(10, y, 200, 24, 16, (char *)label, LABEL_COLOR);
    sprintf(val_buf, "%3d", value);
    sprintf(disp_buf, "%s %s", val_buf, unit);
    lcd_show_string(150, y, 200, 24, 16, disp_buf, VALUE_COLOR);
}

static void update_sensor_display(SensorData_t *sensor)
{
    if (sensor) {
        display_sensor_line_float(SENSOR_START_Y, "Temperature:", sensor->temperature, "C");
        display_sensor_line_float(SENSOR_START_Y + SENSOR_LINE_H, "Humidity:", sensor->humidity, "%");
        display_sensor_line_int(SENSOR_START_Y + SENSOR_LINE_H * 2, "Light:", sensor->light, "%");
        display_sensor_line_int(SENSOR_START_Y + SENSOR_LINE_H * 3, "Soil Moisture:", sensor->soil_moisture, "%");
    }
}

static void draw_menu(void)
{
    uint16_t y0 = MENU_START_Y;
    uint16_t y1 = MENU_START_Y + MENU_ITEM_H;
    lcd_fill(ARROW_X - 5, y0, ARROW_X + 15, y0 + 24, BG_COLOR);
    lcd_fill(ARROW_X - 5, y1, ARROW_X + 15, y1 + 24, BG_COLOR);
    lcd_show_string(TEXT_X, y0, 200, 24, 16, "Threshold Adjust",
                    (g_selected_item == MENU_THRESHOLD) ? MENU_SELECTED_COLOR : MENU_NORMAL_COLOR);
    lcd_show_string(TEXT_X, y1, 200, 24, 16, "Manual Mode",
                    (g_selected_item == MENU_MANUAL) ? MENU_SELECTED_COLOR : MENU_NORMAL_COLOR);
    if (g_selected_item == MENU_THRESHOLD)
        lcd_show_string(ARROW_X, y0, 20, 24, 16, ">", MENU_SELECTED_COLOR);
    else
        lcd_show_string(ARROW_X, y1, 20, 24, 16, ">", MENU_SELECTED_COLOR);
}

static void update_menu_display(void)
{
    if (g_selected_item != g_last_selected_item) {
        draw_menu();
        g_last_selected_item = g_selected_item;
    }
}

/* ==================== ��ֵ�������� ==================== */
static void display_thresholds(uint8_t selected_idx, uint8_t edit_mode, uint8_t edit_idx)
{
    const char *labels[THRESH_COUNT] = {"Temp Threshold:", "Hum Threshold:", "Light Threshold:", "Soil Threshold:"};
    const char *units[THRESH_COUNT] = {"C", "%", "%", "%"};
    uint16_t y_start = 50;
    uint16_t line_h = 30;
    uint16_t arrow_x = 15;
    uint16_t label_x = 40;
    uint16_t value_x = 170;

    lcd_fill(0, 40, lcddev.width - 1, 200, BG_COLOR);

    for (int i = 0; i < THRESH_COUNT; i++) {
        uint16_t y = y_start + i * line_h;
        uint16_t color = (edit_mode && i == edit_idx) ? RED : WHITE;
        char buf[16];
        lcd_show_string(label_x, y, 200, 24, 16, (char *)labels[i], color);
        sprintf(buf, "%d %s", g_thresholds[i], units[i]);
        lcd_show_string(value_x, y, 100, 24, 16, buf, color);
        if (!edit_mode && i == selected_idx) {
            lcd_show_string(arrow_x, y, 20, 24, 16, ">", WHITE);
        }
    }
    if (edit_mode) {
        lcd_show_string(10, 210, 300, 24, 16, "KEY0/KEY1: +/-   KEY2: save", CYAN);
    } else {
        lcd_show_string(10, 210, 300, 24, 16, "KEY0/KEY1: select   KEY2: edit   WK_UP: back", CYAN);
    }
}

static void update_threshold_value(uint8_t idx, uint16_t color)
{
    const char *units[THRESH_COUNT] = {"C", "%", "%", "%"};
    uint16_t y = 50 + idx * 30;
    char buf[16];
    lcd_fill(170, y, 220, y + 20, BG_COLOR);
    sprintf(buf, "%d %s", g_thresholds[idx], units[idx]);
    lcd_show_string(170, y, 100, 24, 16, buf, color);
}

static void update_threshold_arrow(uint8_t old_idx, uint8_t new_idx)
{
    uint16_t old_y = 50 + old_idx * 30;
    uint16_t new_y = 50 + new_idx * 30;
    lcd_fill(15, old_y, 30, old_y + 20, BG_COLOR);
    lcd_show_string(15, new_y, 20, 24, 16, ">", WHITE);
}

static void enter_threshold_menu(void)
{
    uint8_t selected = 0;
    uint8_t edit_mode = 0;
    uint8_t edit_idx = 0;
    uint8_t need_full_redraw = 1;

    lcd_disable_cache();

    while (1) {
        if (need_full_redraw) {
            lcd_clear(BG_COLOR);
            lcd_show_string(10, 10, 300, 24, 16, "Threshold Settings", WHITE);
            display_thresholds(selected, edit_mode, edit_idx);
            lcd_refresh();
            need_full_redraw = 0;
        }

        uint8_t key = key_scan(0);
        if (key == WKUP_PRES) {
            save_thresholds();
            break;
        }

        if (!edit_mode) {
            if (key == KEY0_PRES) {
                uint8_t old = selected;
                if (selected > 0) selected--;
                else selected = THRESH_COUNT - 1;
                update_threshold_arrow(old, selected);
                lcd_refresh();
            } else if (key == KEY1_PRES) {
                uint8_t old = selected;
                if (selected < THRESH_COUNT - 1) selected++;
                else selected = 0;
                update_threshold_arrow(old, selected);
                lcd_refresh();
            } else if (key == KEY2_PRES) {
                edit_mode = 1;
                edit_idx = selected;
                need_full_redraw = 1;
            }
        } else {
            if (key == KEY0_PRES) {
                if (g_thresholds[edit_idx] > 0) {
                    g_thresholds[edit_idx]--;
                    update_threshold_value(edit_idx, RED);
                    lcd_refresh();
                }
            } else if (key == KEY1_PRES) {
                if (g_thresholds[edit_idx] < 100) {
                    g_thresholds[edit_idx]++;
                    update_threshold_value(edit_idx, RED);
                    lcd_refresh();
                }
            } else if (key == KEY2_PRES) {
                edit_mode = 0;
                need_full_redraw = 1;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }

    lcd_enable_cache();
    lcd_clear(BG_COLOR);
    g_last_selected_item = MENU_COUNT;
}

/* ==================== �ֶ�ģʽ���� ==================== */
typedef enum {
    MANUAL_DEVICE_FAN = 0,
    MANUAL_DEVICE_PUMP,
    MANUAL_DEVICE_LIGHT,
    MANUAL_DEVICE_COUNT
} manual_device_t;

static uint8_t g_device_states[MANUAL_DEVICE_COUNT] = {0, 0, 0};
static const char *device_names[MANUAL_DEVICE_COUNT] = {"Fan", "Pump", "Light"};

#define MANUAL_Y_START      50
#define MANUAL_LINE_H       40
#define MANUAL_ARROW_X      15
#define MANUAL_LABEL_X      50
#define MANUAL_STATE_X      180
#define MANUAL_STATE_WIDTH  80

static void fan_control(uint8_t on_off) {
    device_control(DEVICE_FAN, on_off ? DEVICE_ON : DEVICE_OFF);
}
static void pump_control(uint8_t on_off) {
    device_control(DEVICE_PUMP, on_off ? DEVICE_ON : DEVICE_OFF);
}
static void light_control(uint8_t on_off) {
    device_control(DEVICE_LIGHT, on_off ? DEVICE_ON : DEVICE_OFF);
}

static void (*device_control_functions[MANUAL_DEVICE_COUNT])(uint8_t) = {
    fan_control,
    pump_control,
    light_control
};

static void display_manual_control(uint8_t selected_idx)
{
    lcd_fill(0, 40, lcddev.width - 1, 200, BG_COLOR);
    for (int i = 0; i < MANUAL_DEVICE_COUNT; i++) {
        uint16_t y = MANUAL_Y_START + i * MANUAL_LINE_H;
        uint16_t color = (i == selected_idx) ? MENU_SELECTED_COLOR : MENU_NORMAL_COLOR;
        char buf[8];
        lcd_show_string(MANUAL_LABEL_X, y, 100, 24, 16, (char *)device_names[i], color);
        sprintf(buf, "%s", g_device_states[i] ? "ON" : "OFF");
        lcd_show_string(MANUAL_STATE_X, y, MANUAL_STATE_WIDTH, 24, 16, buf, (g_device_states[i] ? GREEN : RED));
        if (i == selected_idx) {
            lcd_show_string(MANUAL_ARROW_X, y, 20, 24, 16, ">", MENU_SELECTED_COLOR);
        }
    }
    lcd_show_string(10, 200, 300, 24, 16, "KEY0/KEY1: select   KEY2: toggle   WK_UP: back", CYAN);
}

static void enter_manual_mode(void)
{
    uint8_t selected = 0;
    uint8_t need_full_redraw = 1;

    /* �����ֶ�ģʽ�������Զ����� */
    g_auto_mode_enabled = 0;

    /* ͬ��ʵ������״̬���ֶ�ģʽ�������� */
    g_device_states[MANUAL_DEVICE_FAN]   = (device_get_state(DEVICE_FAN) == DEVICE_ON) ? 1 : 0;
    g_device_states[MANUAL_DEVICE_PUMP]  = (device_get_state(DEVICE_PUMP) == DEVICE_ON) ? 1 : 0;
    g_device_states[MANUAL_DEVICE_LIGHT] = (device_get_state(DEVICE_LIGHT) == DEVICE_ON) ? 1 : 0;

    lcd_disable_cache();

    while (1) {
        if (need_full_redraw) {
            lcd_clear(BG_COLOR);
            lcd_show_string(10, 10, 300, 24, 16, "Manual Control Mode", WHITE);
            display_manual_control(selected);
            lcd_refresh();
            need_full_redraw = 0;
        }

        uint8_t key = key_scan(0);
        if (key == WKUP_PRES) {
            break;
        }

        if (key == KEY0_PRES) {
            if (selected > 0) selected--;
            else selected = MANUAL_DEVICE_COUNT - 1;
            need_full_redraw = 1;
        } else if (key == KEY1_PRES) {
            if (selected < MANUAL_DEVICE_COUNT - 1) selected++;
            else selected = 0;
            need_full_redraw = 1;
        } else if (key == KEY2_PRES) {
            g_device_states[selected] = !g_device_states[selected];
            device_control_functions[selected](g_device_states[selected]);
            need_full_redraw = 1;
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }

    lcd_enable_cache();
    lcd_clear(BG_COLOR);
    g_last_selected_item = MENU_COUNT;

    /* �˳��ֶ�ģʽ���ָ��Զ����� */
    g_auto_mode_enabled = 1;
}

/* ==================== �˵���ʼ������ѭ�� ==================== */
void menu_init(void)
{
    w25q64_init();
    load_thresholds();

    devices_init();

    lcd_enable_cache();
    lcd_clear(BG_COLOR);
    g_back_color = BG_COLOR;
    g_last_selected_item = MENU_COUNT;
}

void menu_main(void)
{
    static uint8_t initialized = 0;
    if (!initialized) {
        menu_init();
        initialized = 1;
    }

    SensorData_t sensor_data = {0};
    SensorData_t *p_sensor = NULL;

    while (1)
    {
        /* ʹ�� xQueuePeek ���� xQueueReceive���������ݱ��Ƴ� */
        if (xQueuePeek(xSensorQueue, &sensor_data, 0) == pdTRUE) {
            p_sensor = &sensor_data;
        }

        if (p_sensor) {
            update_sensor_display(p_sensor);
        }
        update_menu_display();
        lcd_refresh();

        uint8_t key = key_scan(0);
        if (key == KEY0_PRES) {
            if (g_selected_item > 0) g_selected_item--;
            else g_selected_item = MENU_COUNT - 1;
        } else if (key == KEY1_PRES) {
            if (g_selected_item < MENU_COUNT - 1) g_selected_item++;
            else g_selected_item = 0;
        } else if (key == KEY2_PRES) {
            if (g_selected_item == MENU_THRESHOLD) {
                enter_threshold_menu();
                p_sensor = NULL;
            } else {
                enter_manual_mode();
                p_sensor = NULL;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}
