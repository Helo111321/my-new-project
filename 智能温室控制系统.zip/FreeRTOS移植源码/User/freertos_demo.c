#include "freertos_demo.h"
#include "./SYSTEM/usart/usart.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/DHT11/dht11.h"
#include "./BSP/ADC/adc.h"
#include "./BSP/LSENS/lsens.h"
#include "./BSP/MENU/menu.h"
#include "./BSP/SPI/spi.h"
#include "./BSP/WDG/wdg.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* ���о�� */
QueueHandle_t xSensorQueue;

/* ��ֵ������������ menu.c �ж��壩*/
extern int16_t g_thresholds[4];

/* ������־ */
volatile uint8_t g_alert_active = 0;

/* �Զ�ģʽʹ�ܱ�־��������*/
volatile uint8_t g_auto_mode_enabled = 1;

/* �������� */
#define START_TASK_PRIO 1
#define START_STK_SIZE  128
TaskHandle_t StartTask_Handler;
void start_task(void *pvParameters);

#define SensorTask_PRIO      2
#define SensorTask_STK_SIZE  128
TaskHandle_t SensorTask_Handler;
void SensorTask(void *pvParameters);

#define MenuTask_PRIO      3
#define MenuTask_STK_SIZE  128
TaskHandle_t MenuTask_Handler;
void MenuTask(void *pvParameters);

#define IWDG_TASK_PRIO      2
#define IWDG_TASK_STK_SIZE  128
TaskHandle_t IwdgTask_Handler;
void IwdgTask(void *pvParameters);

#define AUTOCtrlTask_PRIO      2
#define AUTOCtrlTask_STK_SIZE  128
TaskHandle_t AutoCtrlTask_Handler;
void AutoCtrlTask(void *pvParameters);

#define BuzzerTask_PRIO        1
#define BuzzerTask_STK_SIZE    128
TaskHandle_t BuzzerTask_Handler;
void BuzzerTask(void *pvParameters);

#define IWDG_PRESCALER      IWDG_PRESCALER_64
#define IWDG_RELOAD         1250

void freertos_demo(void)
{
    xSensorQueue = xQueueCreate(1, sizeof(SensorData_t));
    if (xSensorQueue == NULL) {
        printf("Queue creation failed!\r\n");
        return;
    }

    xTaskCreate(start_task, "start_task", START_STK_SIZE, NULL, START_TASK_PRIO, &StartTask_Handler);

    iwdg_init(IWDG_PRESCALER, IWDG_RELOAD);
    iwdg_feed();

    vTaskStartScheduler();
}

void start_task(void *pvParameters)
{
    taskENTER_CRITICAL();
    xTaskCreate(SensorTask, "SensorTask", SensorTask_STK_SIZE, NULL, SensorTask_PRIO, &SensorTask_Handler);
    xTaskCreate(MenuTask,   "MenuTask",   MenuTask_STK_SIZE,   NULL, MenuTask_PRIO,   &MenuTask_Handler);
    xTaskCreate(IwdgTask,   "IwdgTask",   IWDG_TASK_STK_SIZE,  NULL, IWDG_TASK_PRIO,  &IwdgTask_Handler);
    xTaskCreate(AutoCtrlTask, "AutoCtrlTask", AUTOCtrlTask_STK_SIZE, NULL, AUTOCtrlTask_PRIO, &AutoCtrlTask_Handler);
    xTaskCreate(BuzzerTask, "BuzzerTask", BuzzerTask_STK_SIZE, NULL, BuzzerTask_PRIO, &BuzzerTask_Handler);
    vTaskDelete(StartTask_Handler);
    taskEXIT_CRITICAL();
}

void SensorTask(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    SensorData_t sensor;

    while (1) {
        DHT11_Data dht;
        if (DHT11_Read(&dht) == DHT11_OK) {
            sensor.temperature = dht.temperature + dht.temp_decimal / 10.0f;
            sensor.humidity    = dht.humidity    + dht.humi_decimal / 10.0f;
        }
        sensor.light         = lsens_get_val();
        sensor.soil_moisture = soil_get_val();

        xQueueOverwrite(xSensorQueue, &sensor);
        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(1000));
    }
}

void MenuTask(void *pvParameters)
{
    menu_main();
}

void IwdgTask(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    while (1) {
        iwdg_feed();
        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(1000));
    }
}

/* �Զ���������֧���ֶ�ģʽ���ã�*/
void AutoCtrlTask(void *pvParameters)
{
    SensorData_t sensor;
    static uint8_t fan_state = 0, pump_state = 0, light_state = 0;
    const float TEMP_HYST = 2.0f;
    const uint16_t SOIL_HYST = 5;
    const uint16_t LIGHT_HYST = 10;

    while (1)
    {
        if (xQueuePeek(xSensorQueue, &sensor, 0) == pdTRUE)
        {
            int16_t temp_thresh = g_thresholds[0];
            int16_t soil_thresh = g_thresholds[3];
            int16_t light_thresh = g_thresholds[2];

            if (g_auto_mode_enabled)
            {
                /* �Զ������߼� */
                if (sensor.temperature > temp_thresh)
                    fan_state = 1;
                else if (sensor.temperature < temp_thresh - TEMP_HYST)
                    fan_state = 0;
                device_control(DEVICE_FAN, fan_state ? DEVICE_ON : DEVICE_OFF);

                if (sensor.soil_moisture < soil_thresh)
                    pump_state = 1;
                else if (sensor.soil_moisture > soil_thresh + SOIL_HYST)
                    pump_state = 0;
                device_control(DEVICE_PUMP, pump_state ? DEVICE_ON : DEVICE_OFF);

                if (sensor.light < light_thresh)
                    light_state = 1;
                else if (sensor.light > light_thresh + LIGHT_HYST)
                    light_state = 0;
                device_control(DEVICE_LIGHT, light_state ? DEVICE_ON : DEVICE_OFF);

                /* �����������¶ȹ��� �� �������� */
                uint8_t alert = (sensor.temperature > temp_thresh) || (sensor.soil_moisture < soil_thresh);
                g_alert_active = alert;
            }
            else
            {
                /* �ֶ�ģʽ�£�����������رշ������������豸���Զ����� */
                g_alert_active = 0;
                device_control(DEVICE_BUZZER, DEVICE_OFF);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/* ��������˸���� */
void BuzzerTask(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    uint8_t buzzer_on = 0;

    while (1)
    {
        if (g_alert_active)
        {
            buzzer_on = !buzzer_on;
            device_control(DEVICE_BUZZER, buzzer_on ? DEVICE_ON : DEVICE_OFF);
            vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(300));
        }
        else
        {
            device_control(DEVICE_BUZZER, DEVICE_OFF);
            vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(500));
        }
    }
}
